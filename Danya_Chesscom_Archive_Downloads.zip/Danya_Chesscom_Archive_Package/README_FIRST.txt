DANIEL “DANYA” NARODITSKY — CHESS.COM ARCHIVE PACKAGE
=========================================================

START HERE
----------
Double-click:
    START_HERE_Danya_Chesscom_Archive.html

That file opens a searchable catalog in your web browser. It contains:
    • 99 official Chess.com article links
    • The complete five-part 2019 “How to Be Lucky In Chess” lesson series
      (one series link plus five individual lesson links)
    • Seven selected commentary-broadcast or highlight links
    • One link to Chess.com’s permanent archive page

OTHER WAYS TO USE THE PACKAGE
-----------------------------
1. Individual Windows shortcuts
   Open the folders 01_Articles, 02_Video_Lessons, and
   03_Broadcasts_and_Highlights. Double-click any .url file.

2. Browser bookmarks
   Import Danya_Chesscom_Browser_Bookmarks.html into Chrome, Edge,
   Firefox, or another browser that accepts Netscape-format bookmark files.

3. Spreadsheet catalog
   Open Danya_Chesscom_Archive_Catalog.xlsx to sort or filter the collection.
   A plain CSV version is also included.

IMPORTANT
---------
This package does NOT contain copied article text or downloaded video files.
It is an organized collection of official links and shortcuts. Internet access
is required. Chess.com and YouTube control access, sign-in requirements, and
availability. The four Speed Chess Championship entries point to the Broadcasts
section of Chess.com’s official archive because the broadcasts are embedded
there.

SOURCE
------
Chess.com permanent archive:
Daniel Naroditsky's Articles, Videos, And Commentary On Chess.com
https://www.chess.com/article/view/naroditsky-chess-articles-videos-commentary

Catalog prepared August 25, 2026.
